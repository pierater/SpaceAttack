SPACEATTACK:
	A Galaga clone written in C++ and using the ncurses library.


Contributers:
	
	Martin Almaraz:
		Contributed Work:
			General UI, Main game screen, collision tracking, lazer movement, Enemy spawn and movement, Score tracking, lives tracking
	
	Ed Garcia:
		Contributed Work:
			Ncurses implemtation, game design
	
	Jozy Garcia:
		Contributed Work:
			Galaga ASCII art, SpaceShip movement
